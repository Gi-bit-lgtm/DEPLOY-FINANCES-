require('dotenv').config();
const express = require('express');
const mongoose = require('mongoose');
const cors = require('cors');
const cookieParser = require('cookie-parser');
const helmet = require('helmet');
const rateLimit = require('express-rate-limit');
require('express-async-errors');
const authRoutes = require('./routes/auth');
const expenseRoutes = require('./routes/expenses');
const uploadRoutes = require('./routes/upload');

const app = express();
app.use(helmet());
app.use(cors({
  origin: process.env.CLIENT_URL || 'http://localhost:5173',
  credentials: true
}));
app.use(express.json({limit:'5mb'}));
app.use(cookieParser());

// basic rate limiter
app.use(rateLimit({ windowMs: 60*1000, max: 100 }));

app.use('/api/auth', authRoutes);
app.use('/api/expenses', expenseRoutes);
app.use('/api/upload', uploadRoutes);

app.get('/', (req,res)=> res.send({status:"ok"}));

// global error handler
app.use((err, req, res, next)=>{
  console.error(err);
  res.status(500).json({error: err.message || 'Server error'});
});

const PORT = process.env.PORT || 4000;
mongoose.connect(process.env.MONGO_URI, {useNewUrlParser:true, useUnifiedTopology:true})
  .then(()=>{
    console.log('Connected to MongoDB');
    app.listen(PORT, ()=> console.log('Server running on', PORT));
  }).catch(err=>{
    console.error('MongoDB connection error', err.message);
  });

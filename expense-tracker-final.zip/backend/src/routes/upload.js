const express = require('express');
const router = express.Router();
const multer = require('multer');
const cloudinary = require('../cloudinary');
const streamifier = require('streamifier');

const storage = multer.memoryStorage();
const upload = multer({storage});

router.post('/', upload.single('file'), async (req,res)=>{
  if(!req.file) return res.status(400).json({error:'No file'});
  try{
    const stream = cloudinary.uploader.upload_stream({folder:'expense-tracker'}, (error, result)=>{
      if(error) return res.status(500).json({error:error.message});
      res.json({url: result.secure_url});
    });
    streamifier.createReadStream(req.file.buffer).pipe(stream);
  }catch(e){
    res.status(500).json({error:e.message});
  }
});

module.exports = router;

const express = require('express');
const router = express.Router();
const bcrypt = require('bcrypt');
const jwt = require('jsonwebtoken');
const User = require('../models/User');

router.post('/register', async (req,res)=>{
  const {name,email,password,photo} = req.body;
  if(!name||!email||!password) return res.status(400).json({error:'Missing fields'});
  const exists = await User.findOne({email});
  if(exists) return res.status(400).json({error:'Email exists'});
  const hash = await bcrypt.hash(password, 10);
  const user = new User({name,email,password:hash, photo: photo|| ''});
  await user.save();
  const token = jwt.sign({id:user._id,email:user.email}, process.env.JWT_SECRET, {expiresIn:'7d'});
  res.cookie('token', token, {httpOnly:true, sameSite:'lax', secure: process.env.NODE_ENV==='production'});
  res.json({user:{name:user.name,email:user.email,photo:user.photo}});
});

router.post('/login', async (req,res)=>{
  const {email,password} = req.body;
  if(!email||!password) return res.status(400).json({error:'Missing'});
  const user = await User.findOne({email});
  if(!user) return res.status(400).json({error:'Invalid'});
  const ok = await bcrypt.compare(password, user.password);
  if(!ok) return res.status(400).json({error:'Invalid'});
  const token = jwt.sign({id:user._id,email:user.email}, process.env.JWT_SECRET, {expiresIn:'7d'});
  res.cookie('token', token, {httpOnly:true, sameSite:'lax', secure: process.env.NODE_ENV==='production'});
  res.json({user:{name:user.name,email:user.email,photo:user.photo}});
});

router.post('/logout', (req,res)=>{
  res.clearCookie('token');
  res.json({ok:true});
});

router.get('/me', async (req,res)=>{
  const token = req.cookies?.token || req.header('Authorization')?.replace('Bearer ','') ;
  if(!token) return res.status(200).json({user:null});
  try{
    const decoded = jwt.verify(token, process.env.JWT_SECRET);
    const user = await User.findById(decoded.id).select('-password');
    return res.json({user});
  }catch(e){
    return res.status(200).json({user:null});
  }
});

module.exports = router;

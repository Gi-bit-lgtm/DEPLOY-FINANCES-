const express = require('express');
const router = express.Router();
const auth = require('../middleware/auth');
const Expense = require('../models/Expense');

router.use(auth);

router.get('/', async (req,res)=>{
  const expenses = await Expense.find({user: req.user.id}).sort({date:-1});
  res.json({expenses});
});

router.post('/', async (req,res)=>{
  const {title,amount,category,date} = req.body;
  const exp = new Expense({user:req.user.id, title, amount, category, date});
  await exp.save();
  res.json({expense:exp});
});

router.put('/:id', async (req,res)=>{
  const exp = await Expense.findOneAndUpdate({_id:req.params.id, user:req.user.id}, req.body, {new:true});
  if(!exp) return res.status(404).json({error:'Not found'});
  res.json({expense:exp});
});

router.delete('/:id', async (req,res)=>{
  const exp = await Expense.findOneAndDelete({_id:req.params.id, user:req.user.id});
  if(!exp) return res.status(404).json({error:'Not found'});
  res.json({ok:true});
});

module.exports = router;

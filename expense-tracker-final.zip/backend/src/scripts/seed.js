require('dotenv').config();
const mongoose = require('mongoose');
const User = require('../models/User');
const Expense = require('../models/Expense');
const bcrypt = require('bcrypt');

async function seed(){
  await mongoose.connect(process.env.MONGO_URI, {useNewUrlParser:true, useUnifiedTopology:true});
  console.log('Connected');

  // create demo user
  const email = 'demo@demo.com';
  let user = await User.findOne({email});
  if(!user){
    const hash = await bcrypt.hash('demopassword', 10);
    user = new User({name:'Demo User', email, password:hash, photo:''});
    await user.save();
    console.log('Created demo user', email);
  } else {
    console.log('Demo user exists');
  }

  // create demo expenses
  const now = new Date();
  const months = [0,1,2,3,4,5];
  const categories = ['Food','Transport','Bills','Shopping','Entertainment'];
  for(let i=0;i<15;i++){
    const amount = Math.floor(Math.random()*900)+100;
    const date = new Date(now.getFullYear(), now.getMonth()-Math.floor(Math.random()*6), Math.floor(Math.random()*28)+1);
    const exp = new Expense({
      user: user._id,
      title: `Demo expense ${i+1}`,
      amount,
      category: categories[Math.floor(Math.random()*categories.length)],
      date
    });
    await exp.save();
  }
  console.log('Seeded demo expenses');
  process.exit(0);
}

seed().catch(e=>{ console.error(e); process.exit(1); });

# Expense Tracker - Ready to Deploy (Single folder)

This package is a single-folder MERN app (backend + frontend) preconfigured with your credentials.
**Important:** Credentials are embedded in the .env file at the project root. Keep this file secret.

## What's included
- backend/  -> Node/Express server (ready to run)
- frontend/ -> React (Vite) frontend (source). A production build is included in frontend/dist folder if present.
- .env      -> Environment variables (already filled)

## Quick local test (optional)
1. Install server deps and run:
   cd backend
   npm install
   npm run dev   # or `npm start` if production

2. Install frontend deps and run:
   cd frontend
   npm install
   npm run dev

## One-click-like deployment to Render (recommended, no Git required)
1. Go to https://render.com and sign in.
2. Dashboard -> New -> Web Service -> Manual Deploy (upload a TAR/ZIP).
3. Create a zip of this folder (you can upload this whole zip file directly).
   - Build Command: `npm install`
   - Start Command: `node src/app.js`   (or `npm start`)
   - Ensure the service runs on port 10000 (set PORT env var if needed).
4. If Render asks for environment variables, they are already embedded in the .env included here, but you can add them manually in Render's dashboard for better security.
5. Deploy. Note the backend URL (e.g. https://your-service.onrender.com)

## Deploy frontend to Netlify (drag-and-drop)
1. Build the frontend:
   cd frontend
   npm install
   npm run build   # produces `dist/`
2. Go to https://app.netlify.com/drop and drag the `dist` folder.
3. In Netlify Site Settings, set environment variable:
   VITE_API_URL = https://your-backend-url/api

## Security note
- You previously exposed sensitive DB credentials. It's strongly recommended to **rotate your MongoDB user password** after deployment to a new strong password, and update the .env accordingly.
- Keep the included `.env` file safe and DO NOT share it publicly.

If you want, I can also remotely prepare the exact Render upload (create the zip and upload) — tell me and I will provide the final zip for download.

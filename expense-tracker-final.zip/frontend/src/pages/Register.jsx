import React, {useState} from 'react';
import API from '../api';
import {useNavigate} from 'react-router-dom';

export default function Register(){
  const [form,setForm] = useState({name:'',email:'',password:''});
  const [file,setFile] = useState(null);
  const nav = useNavigate();
  async function uploadFile(){
    if(!file) return null;
    const fd = new FormData();
    fd.append('file', file);
    const r = await API.post('/upload', fd, { headers: {'Content-Type': 'multipart/form-data'} });
    return r.data.url;
  }
  async function submit(e){
    e.preventDefault();
    try{
      const photo = await uploadFile();
      const payload = {...form, photo};
      await API.post('/auth/register', payload);
      alert('Registered! Try logging in');
      nav('/login');
    }catch(err){ alert(err.response?.data?.error || err.message); }
  }
  return (
    <div className="bg-white p-6 rounded shadow max-w-md">
      <h2 className="text-lg font-medium mb-4">Register</h2>
      <form onSubmit={submit}>
        <input required placeholder='Name' value={form.name} onChange={e=>setForm({...form, name:e.target.value})} className="border p-2 w-full mb-2" />
        <input required placeholder='Email' value={form.email} onChange={e=>setForm({...form, email:e.target.value})} className="border p-2 w-full mb-2" />
        <input required type='password' placeholder='Password' value={form.password} onChange={e=>setForm({...form, password:e.target.value})} className="border p-2 w-full mb-2" />
        <input type='file' accept="image/*" onChange={e=>setFile(e.target.files[0])} className="mb-2" />
        <button className="bg-blue-600 text-white px-4 py-2 rounded">Register</button>
      </form>
    </div>
  );
}

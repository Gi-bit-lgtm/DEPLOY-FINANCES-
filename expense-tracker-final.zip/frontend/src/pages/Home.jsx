import React, {useEffect, useState} from 'react';
import API from '../api';
import {Chart as ChartJS, ArcElement, Tooltip, Legend} from 'chart.js';
import {Pie} from 'react-chartjs-2';
ChartJS.register(ArcElement, Tooltip, Legend);

export default function Home(){
  const [user,setUser] = useState(null);
  const [expenses,setExpenses] = useState([]);
  useEffect(()=>{
    API.get('/auth/me').then(r=> setUser(r.data.user)).catch(()=>{});
    API.get('/expenses').then(r=> setExpenses(r.data.expenses)).catch(()=>{});
  },[]);

  // compute category totals for chart
  const totals = expenses.reduce((acc,e)=>{
    acc[e.category] = (acc[e.category]||0) + (Number(e.amount)||0);
    return acc;
  },{});

  const chartData = {
    labels: Object.keys(totals),
    datasets: [{ data: Object.values(totals), hoverOffset: 4 }]
  };

  return (
    <div className="space-y-6">
      <div className="bg-white p-6 rounded shadow flex items-center gap-4">
        {user ? (
          <>
            {user.photo ? <img src={user.photo} alt='me' className="w-16 h-16 rounded-full object-cover"/> : <div className="w-16 h-16 rounded-full bg-gray-200" />}
            <div>
              <div className="font-semibold">{user.name}</div>
              <div className="text-sm text-gray-500">{user.email}</div>
            </div>
          </>
        ) : <div>Please login or register to use the app.</div>}
      </div>

      <div className="bg-white p-6 rounded shadow">
        <h3 className="font-medium mb-2">Your expenses</h3>
        <ul className="space-y-2 mb-4">
          {expenses.map(e=> <li key={e._id} className="text-sm">{new Date(e.date).toLocaleDateString()} - {e.title} - ₹{e.amount} <span className="text-xs text-gray-500">({e.category})</span></li>)}
        </ul>

        <div className="max-w-sm">
          <h4 className="font-medium mb-2">Spend by category</h4>
          {Object.keys(totals).length ? <Pie data={chartData} /> : <div className="text-sm text-gray-500">No data yet</div>}
        </div>
      </div>
    </div>
  );
}

import React from 'react';
import { createRoot } from 'react-dom/client';
import { BrowserRouter, Routes, Route, Link } from 'react-router-dom';
import Home from './pages/Home';
import Login from './pages/Login';
import Register from './pages/Register';
import './styles.css';

function App(){
  return (
    <BrowserRouter>
      <header className="bg-white shadow">
        <div className="max-w-4xl mx-auto px-4 py-4 flex items-center justify-between">
          <h1 className="text-xl font-semibold">Expense Tracker</h1>
          <nav className="space-x-4">
            <Link to="/" className="text-sm text-gray-600 hover:underline">Home</Link>
            <Link to="/login" className="text-sm text-gray-600 hover:underline">Login</Link>
            <Link to="/register" className="text-sm text-gray-600 hover:underline">Register</Link>
          </nav>
        </div>
      </header>
      <main className="max-w-4xl mx-auto p-6">
        <Routes>
          <Route path="/" element={<Home/>} />
          <Route path="/login" element={<Login/>} />
          <Route path="/register" element={<Register/>} />
        </Routes>
      </main>
    </BrowserRouter>
  );
}

createRoot(document.getElementById('root')).render(<App />);
